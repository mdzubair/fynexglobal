export default function Footer() {
  return (
    <footer className="bg-[#0b0e11] border-t border-gray-700 flex items-center justify-center text-xs text-gray-400">
      © 2025 Trading Terminal — demo
    </footer>
  );
}
